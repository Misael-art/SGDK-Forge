-- Rundown back alley --

(These files originate from http://ngmc.retrogames.com)

Topics: 

* What's this?
* What's needed?
* What's new?
* Comments
* Credits

-- What's this? --

This is the stage "Rundown back alley" from Street fighter alpha 2,
adapted for play with Elecbyte's fighting game engine M.U.G.E.N. by me,
NeoGouki (gouki@hem.passagen.se).

-- What's needed? --

First of all, the newest revision of the M.U.G.E.N. engine which can be found at
http://www.elecbyte.com. Secondly, all the files contained within the archive
bckalley.zip which are:

* bckalley.def 
* bckalley.sff 

Unzip all the files into the "stages" sub-directory of the directory where you
keep the M.U.G.E.N. engine. Add the stage to your list of playable stages by
opening up "select.def" and simply add the line "stages/bckalley.def", either under
the section of "extra" stages or as a character specific stage.

-- What's new? --

Everything...

-- Comments --

Originally there were two moths flying by the lantern, but I couldn't give a rat's
ass about the second as it kept flickering in and out and was a general pain in the butt.

-- Credits --

* Capcom, as the original creators of this background.
* I have to credit myself of course, for taking the time to convert this stage to
  the M.U.G.E.N. format.
* Elecbyte, for creating the wonderful M.U.G.E.N. engine and letting us experience
  the match-ups of our dreams.
* TESTP, for being a great support in the everyday struggle of character making
  and being nice guys in general.
* All the great guys and girls over at the TESTP message board who can be a great
  resource from time to time.