;-| Super Motions |--------------------------------------------------------

[Command]
name = "power_b"
command = ~F, B, DB, D, DF, b
time = 30

[Command]
name = "power_c"
command = ~F, B, DB, D, DF, c
time = 30

[Command]
name = "power_bc"
command = ~F, B, DB, D, DF, b+c
time = 30

;-| Special Motions |------------------------------------------------------

[Command]
name = "qcf_a"
command = ~D, DF, F, a
time = 15

[Command]
name = "qcf_c"
command = ~D, DF, F, c
time = 15

[Command]
name = "qcb_a"
command = ~D, DB, B, a
time = 15

[Command]
name = "charge_c"
command = ~45$D, U, c
time = 10

[Command]
name = "qcb_c"
command = ~D, DB, B, c
time = 15

[Command]
name = "hcf_c"
command = ~B, DB, D, DF, F, c
time = 25

[Command]
name = "fake"
command = D, a+b
time = 3

;-| Double Tap |-----------------------------------------------------------

[Command]
name = "FF"
command = F, F
time = 10

[Command]
name = "BB"
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------

[Command]
name = "recovery"
command = x+y
time = 1

[Command]
name = "ab"
command = a+b
time = 1

;-| Dir + Button |---------------------------------------------------------

;-| Single Button |---------------------------------------------------------

[Command]
name = "a"
command = a
time = 1

[Command]
name = "hold_a"
command = /a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "hold_b"
command = /b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "hold_c"
command = /c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Command]
name = "s"
command = s
time = 1

;-| Hold Dir |--------------------------------------------------------------

[Command]
name = "holdfwd_x"
command = /$F, x
time = 1

[Command]
name = "holdfwd_y"
command = /$F, y
time = 1

[Command]
name = "holdfwd"
command = /$F
time = 1

[Command]
name = "back"
command = B
time = 1

[Command]
name = "upback"
command = UB
time = 1

[Command]
name = "downback"
command = DB
time = 1

[Command]
name = "holdback"
command = /$B
time = 1

[Command]
name = "holdup"
command = /$U
time = 1

[Command]
name = "holddown"
command = /$D
time = 1

;-|Commands|------------------------------------------------------------------------------

[Statedef -1]

[State -1]
type = ChangeState
value = 2000
triggerall = command = "power_bc" && power >= 1000
trigger1 = statetype != A && ctrl
trigger2 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger3 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger4 = stateno = 210 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger5 = stateno = 230 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger6 = stateno = 235 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger7 = stateno = 240 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger8 = stateno = 270 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger9 = stateno = 400 && AnimElem = 2, >= 1 && MoveContact
trigger10 = stateno = 430 && AnimElem = 2, >= 1 && MoveContact
trigger11 = stateno = 440 && AnimElem = 2, >= 1 && MoveContact
trigger12 = stateno = 475 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact

[State -1]
type = ChangeState
value = 2100
triggerall = command = "power_b" && power >= 2000
trigger1 = statetype != A && ctrl
trigger2 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger3 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger4 = stateno = 210 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger5 = stateno = 230 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger6 = stateno = 235 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger7 = stateno = 240 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger8 = stateno = 270 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger9 = stateno = 400 && AnimElem = 2, >= 1 && MoveContact
trigger10 = stateno = 430 && AnimElem = 2, >= 1 && MoveContact
trigger11 = stateno = 440 && AnimElem = 2, >= 1 && MoveContact
trigger12 = stateno = 475 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact

[State -1]
type = Changestate
value = 2200
triggerall = command = "power_c" && power >= 2000
trigger1 = statetype != A && ctrl
trigger2 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger3 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger4 = stateno = 210 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger5 = stateno = 230 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger6 = stateno = 235 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger7 = stateno = 240 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger8 = stateno = 270 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger9 = stateno = 400 && AnimElem = 2, >= 1 && MoveContact
trigger10 = stateno = 430 && AnimElem = 2, >= 1 && MoveContact
trigger11 = stateno = 440 && AnimElem = 2, >= 1 && MoveContact
trigger12 = stateno = 475 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact

; Kachosen
[State -1]
type = ChangeState
value = 1000
triggerall = command = "qcf_a" && numprojid(1000) = 0
trigger1 = statetype != A && ctrl
trigger2 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger3 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger4 = stateno = 210 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger5 = stateno = 230 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger6 = stateno = 235 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger7 = stateno = 240 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger8 = stateno = 270 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger9 = stateno = 400 && AnimElem = 2, >= 1 && MoveContact
trigger10 = stateno = 430 && AnimElem = 2, >= 1 && MoveContact
trigger11 = stateno = 440 && AnimElem = 2, >= 1 && MoveContact
trigger12 = stateno = 475 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact

; Ryuenbu
[State -1]
type = ChangeState
value = 1100
triggerall = command = "qcb_a"
trigger1 = statetype != A && ctrl
trigger2 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger3 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger4 = stateno = 210 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger5 = stateno = 230 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger6 = stateno = 235 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger7 = stateno = 240 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger8 = stateno = 270 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger9 = stateno = 400 && AnimElem = 2, >= 1 && MoveContact
trigger10 = stateno = 430 && AnimElem = 2, >= 1 && MoveContact
trigger11 = stateno = 440 && AnimElem = 2, >= 1 && MoveContact
trigger12 = stateno = 475 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact

[State -1]
type = ChangeState
value = 1200
triggerall = command = "ab" && command = "holddown"
trigger1 = statetype = A && ctrl

[State -1]
type = ChangeState
value = 1300
triggerall = command = "charge_c"
trigger1 = statetype != A && ctrl
trigger2 = stateno = 40
trigger3 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger4 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger5 = stateno = 210 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger6 = stateno = 230 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger7 = stateno = 235 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger8 = stateno = 240 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger9 = stateno = 270 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger10 = stateno = 400 && AnimElem = 2, >= 1 && MoveContact
trigger11 = stateno = 430 && AnimElem = 2, >= 1 && MoveContact
trigger12 = stateno = 440 && AnimElem = 2, >= 1 && MoveContact
trigger13 = stateno = 475 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact

[State -1]
type = ChangeState
value = 1400
triggerall = command = "qcb_c"
trigger1 = statetype != A && ctrl

[State -1]
type = ChangeState
value = 1450
trigger1 = command = "qcb_c"
trigger1 = stateno = 1400 && AnimElem = 4, >= 1 && AnimElem = 7, < 0

[State -1]
type = ChangeState
value = 1500
trigger1 = command = "qcb_c"
trigger1 = stateno = 1450 && AnimElem = 10, >= 1 && AnimElem = 13, < 0

[State -1]
type = ChangeState
value = 1550
trigger1 = command = "qcb_c"
trigger1 = stateno = 1500 && AnimElem = 10, >= 1 && AnimElem = 12, < 0

[State -1]
type = ChangeState
value = 1600
triggerall = command = "hcf_c"
trigger1 = statetype != A && ctrl
trigger2 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger3 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger4 = stateno = 210 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger5 = stateno = 230 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger6 = stateno = 235 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger7 = stateno = 240 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger8 = stateno = 270 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger9 = stateno = 400 && AnimElem = 2, >= 1 && MoveContact
trigger10 = stateno = 430 && AnimElem = 2, >= 1 && MoveContact
trigger11 = stateno = 440 && AnimElem = 2, >= 1 && MoveContact
trigger12 = stateno = 475 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact

[State -1]
type = ChangeState
value = 1700
triggerall = command = "qcf_c"
trigger1 = statetype != A && ctrl
trigger2 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger3 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger4 = stateno = 210 && AnimElem = 4, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger5 = stateno = 230 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger6 = stateno = 235 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger7 = stateno = 240 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact
trigger8 = stateno = 270 && AnimElem = 3, >= 1 && AnimElem = 7, < 0 && MoveContact
trigger9 = stateno = 400 && AnimElem = 2, >= 1 && MoveContact
trigger10 = stateno = 430 && AnimElem = 2, >= 1 && MoveContact
trigger11 = stateno = 440 && AnimElem = 2, >= 1 && MoveContact
trigger12 = stateno = 475 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveContact

; Wall jump back
[State -1]
type = ChangeState
value = 900
trigger1 = command = "holdup" && command = "holdfwd"
trigger1 = Vel X < 0 && BackEdgeBodyDist <= 15
trigger1 = ctrl
trigger1 = (stateno = 50 && time > 5) || (stateno = 51 && time < 18)

; Wall jump front
[State -1]
type = ChangeState
value = 910
trigger1 = command = "holdup" && command = "holdback"
trigger1 = Vel X > 0 && FrontEdgeBodyDist <= 15
trigger1 = ctrl
trigger1 = (stateno = 50 && time > 5) || (stateno = 51 && time < 18)

; Throw
[State -1]
type = ChangeState
value = 850
trigger1 = command = "holddown" && command = "c"
trigger1 = statetype = A && ctrl && stateno != 48
trigger1 = p2bodydist x <= 15 && (p2dist y <= 15 && p2dist y >= -15)
trigger1 = p2statetype = A && p2movetype != H

; Throw
[State -1]
type = ChangeState
value = 800
trigger1 = command = "holdfwd" && command = "c"
trigger1 = statetype = S && ctrl
trigger1 = p2bodydist x <= 5 && (p2statetype != A || p2movetype != H) && p2stateno != 5120

; Taunt
[State -1]
type = ChangeState
value = 195
trigger1 = command = "c"
trigger1 = Vel X = 0 && p2dist x > 160
trigger1 = statetype = S && ctrl && stateno != 195

[State -1]
type = ChangeState
value = 1800
triggerall = command = "fake"
trigger1 = statetype != A && ctrl
trigger2 = stateno = 10

; Standing Back + A
[State -1]
type = ChangeState
value = 215
trigger1 = command = "a" && command = "holdback"
trigger1 = statetype = S && ctrl

; Standing Light attack
[State -1]
type = ChangeState
value = 200
triggerall = command = "a" && p2bodydist x > 22
trigger1 = statetype = S && ctrl && stateno != 195
trigger2 = stateno = 101 || stateno = 102

; Standing close Light attack
[State -1]
type = ChangeState
value = 205
triggerall = command = "a"
trigger1 = statetype = S && ctrl && stateno != 195
trigger2 = stateno = 101 || stateno = 102

; Standing combo Light attack
[State -1]
type = ChangeState
value = 210
triggerall = command = "a"
trigger1 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0
trigger2 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0
trigger3 = stateno = 400 && AnimElem = 2, >= 1 && command != "holddown"

; Standing Medium attack
[State -1]
type = ChangeState
value = 230
triggerall = command = "b" && p2bodydist x > 38
trigger1 = statetype = S && ctrl && stateno != 195
trigger2 = stateno = 101 || stateno = 102

; Standing close Medium attack
[State -1]
type = ChangeState
value = 235
triggerall = command = "b"
trigger1 = statetype = S && ctrl && stateno != 195
trigger2 = stateno = 101 || stateno = 102

; Standing combo Medium attack
[State -1]
type = ChangeState
value = 240
triggerall = command = "b" && command != "holddown"
trigger1 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0
trigger2 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0
trigger3 = stateno = 230 && AnimElem = 3, >= 1 && AnimElem = 7, < 0
trigger4 = stateno = 235 && AnimElem = 3, >= 1 && AnimElem = 6, < 0
trigger5 = stateno = 400 && AnimElem = 2, >= 1
trigger6 = stateno = 430 && AnimElem = 2, >= 1

; Standing Hard attack
[State -1]
type = ChangeState
value = 260
triggerall = command = "c" && p2bodydist x > 22
trigger1 = statetype = S && ctrl && stateno != 195
trigger2 = stateno = 101 || stateno = 102

; Standing close Hard attack
[State -1]
type = ChangeState
value = 265
triggerall = command = "c"
trigger1 = statetype = S && ctrl && stateno != 195
trigger2 = stateno = 101 || stateno = 102

; Standing combo Hard attack A
[State -1]
type = ChangeState
value = 270
triggerall = command = "c" && command != "holddown"
trigger1 = stateno = 210 && AnimElem = 4, >= 1 && AnimElem = 6, < 0
trigger2 = stateno = 240 && AnimElem = 3, >= 1 && AnimElem = 6, < 0

; Standing combo Hard attack B
[State -1]
type = ChangeState
value = 275
trigger1 = command = "c" && command != "holddown"
trigger1 = stateno = 265 && AnimElem = 3, >= 1 && AnimElem = 6, < 0 && MoveHit

; Standing combo Hard attack C
[State -1]
type = ChangeState
value = 280
trigger1 = command = "c" && command != "holddown"
trigger1 = stateno = 276 && AnimElem = 2, >= 1 && AnimElem = 3, < 0

; Standing combo Hard attack D
[State -1]
type = ChangeState
value = 285
trigger1 = command = "c" && command = "holddown"
trigger1 = stateno = 280 && AnimElem = 2, >= 1 && AnimElem = 3, < 0

; Crouching Light attack
[State -1]
type = ChangeState
value = 400
trigger1 = command = "a" && statetype = C && ctrl

; Crouching Medium attack
[State -1]
type = ChangeState
value = 430
trigger1 = command = "b" && statetype = C && ctrl

; Crouching combo Medium attack
[State -1]
type = ChangeState
value = 440
triggerall = command = "b"
trigger1 = stateno = 200 && AnimElem = 4, >= 1 && AnimElem = 6, < 0
trigger2 = stateno = 205 && AnimElem = 2, >= 1 && AnimElem = 7, < 0
trigger3 = stateno = 230 && AnimElem = 3, >= 1 && AnimElem = 7, < 0
trigger4 = stateno = 235 && AnimElem = 3, >= 1 && AnimElem = 6, < 0
trigger5 = stateno = 400 && AnimElem = 2, >= 1
trigger6 = stateno = 430 && AnimElem = 2, >= 1

; Crouching Hard attack
[State -1]
type = ChangeState
value = 460
trigger1 = command = "c" && statetype = C && ctrl

; Crouching combo Hard attack A
[State -1]
type = ChangeState
value = 470
triggerall = command = "c"
trigger1 = stateno = 210 && AnimElem = 4, >= 1 && AnimElem = 6, < 0
trigger2 = stateno = 240 && AnimElem = 3, >= 1 && AnimElem = 6, < 0
trigger3 = stateno = 440 && AnimElem = 2, >= 1 && command = "holddown"

; Crouching combo Hard attack B
[State -1]
type = ChangeState
value = 475
trigger1 = command = "c"
trigger1 = stateno = 400 && AnimElem = 2, >= 1 && command = "holddown"

; Jumping Light attack
[State -1]
type = ChangeState
value = 600
trigger1 = command = "a" && statetype = A && stateno != 48 && ctrl

; Jumping Medium attack
[State -1]
type = ChangeState
value = 630
trigger1 = command = "b" && statetype = A && stateno != 48 && ctrl

; Neutral jumping Hard attack
[State -1]
type = ChangeState
value = 660
trigger1 = command = "c" && statetype = A && stateno != 48 && Vel X = 0 && ctrl

; Diagonal jumping Hard attack
[State -1]
type = ChangeState
value = 675
trigger1 = command = "c" && statetype = A && stateno != 48 && ctrl

; Jumping (short) Light attack
[State -1]
type = ChangeState
value = 605
trigger1 = command = "a" && statetype = A && ctrl

; Jumping (short) Medium attack
[State -1]
type = ChangeState
value = 635
trigger1 = command = "b" && statetype = A && ctrl

; Jumping (short) Hard attack
[State -1]
type = ChangeState
value = 665
trigger1 = command = "c" && statetype = A && ctrl

; Getup attack
[State -1]
type = ChangeState
value = 290
triggerall = command = "c" && alive
trigger1 = stateno = 5100 && Time > 4
trigger2 = stateno = 5120 && AnimElem = 1, >= 0 && AnimElem = 2, < 0

; Arial turning
[State -1]
type = ChangeState
value = 7
trigger1 = command = "y" && statetype = A && stateno != 48 && ctrl

; Crawl forward
[State -1]
type = ChangeState
value = 22
trigger1 = stateno = 11 && command = "holddown" && command = "holdfwd"

; Run Forward
[State -1]
type = ChangeState
value = 100
trigger1 = command = "FF" && command != "holddown"
trigger1 = statetype = S && ctrl

; Run Backwards
[State -1]
type = ChangeState
value = 105
trigger1 = command = "BB" && command != "holddown"
trigger1 = statetype = S && ctrl