--- Mai Shiranui ---

(These files originate from http://ngmc.retrogames.com)

Topics:

* What's this?
* What's needed?
* What's new?
* Comments
* What's done?
* What's left?
* Moveslist
* Credits

--- What's this? ---

This is Mai Shiranui from Real bout Fatal fury special and Real bout Fatal fury 2,
adapted for play with Elecbyte's fighting game engine M.U.G.E.N. by me,
NeoGouki (gouki@hem.passagen.se).

--- What's needed? ---

First of all, the newest revision of the M.U.G.E.N. engine which can be found
at http://www.elecbyte.com. Secondly, all the files contained within
the archive mai.zip which are:

* mai.def
* mai.sff
* mai.snd
* mai.cns
* mai.cmd
* mai01.act
* mai02.act
* mai03.act

Unzip all the files into a sub-directory to the directory where you keep the
M.U.G.E.N. engine called "chars\mai" and add the character to your
character roster by simply adding the line "mai" to your "select.cfg"
under the [Characters] section.

--- What's new? ---

Everything...

--- Comments ---

None at the present.

--- What's done? ---

* 5 pre-fight intros
* 4 win poses
* Taunt
* Time over loss animation
* All getting hit, guarding and falling animations
* All required frames
* Dashing forward and back
* All standing, crouching and jumping normal attacks
* Two throws
* Kachosen
* Midare kachosen
* Ryuu en bu
* Kagero no mai
* Hissatsu shinobi bachi
* Musasabi no mai
* Koya sen tori
* Chou hissatsu shinobi bachi
* Leotard shinobi bachi
* Hana arashi

--- What's left? ---

Nothing...?

--- Moveslist ---

  Light attack
        - A
  Medium attack
        - B
  Hard attack
        - C
  Arial turning
        - Y
        - In the air
  Line push tail
        - b + A
  Double kick
        - C
        - After getting knocked down
  Taunt
        - C
        - Far away from the opponent, standing still
  Leg flip
        - f + C
        - Close to the opponent
  Chest pressure
        - d + C
        - Close to the opponent
        - In the air
  Kachosen
        - d, df, f + A
  Fake Kachosen
        - d + A + B
  Ryuu en bu
        - d, db, b + A
  Musasabi no mai
        - d + A + B
        - In the air
  Kagero no mai
        - hold d, u + C
  Hissatsu shinobi bachi
        - b, db, d, df, f + C
  Midare kachosen
        - (d, db, b + C) x4
  Koya sen tori
        - d, df, f + C
  Chou hissatsu shinobi bachi
        - f, b, db, d, df + BC
        - With power at level 1 or higher
  Leotard shinobi bachi
        - f, b, db, d, df + B
        - With power at level 2 or higher
  Hana arashi
        - f, b, db, d, df, f + C
        - With power at level 2 or higher
        - Hold C to travel forward

-- Combo chart --

  A --->   B --->   C
     |        V
(C)A --> (C)B --> (C)C

  B --->   B --->   C
              V
(C)B --> (C)B --> (C)C

A ---> A ---> C
          V
        (C)C

(C)A ---> (C)C

Close C ---> C ---> C ---> d + C

(Specials can be tagged onto virtually any move
 that doesn't knock the opponent down)

--- Credits ---

* SNK, for making Real bout Fatal fury special, one of the IMHO best fighting games.
* I have to credit myself of course, for taking the time to convert
  this character to the M.U.G.E.N. format.
* Elecbyte, for creating the wonderful M.U.G.E.N. engine and letting us experience
  the match-ups of our dreams.
* TESTP, for being a great support in the everyday struggle of character making
  and being nice guys in general.
* ShadoWatc, for taking a peek at any occasional characters I might throw at him.

