;-| Super Motions |--------------------------------------------------------

[Command]
name = qcfqcf_x
command = ~D, DF, F, D, DF, F, x
time = 30

[Command]
name = qcfqcf_y
command = ~D, DF, F, D, DF, F, y
time = 30

[Command]
name = qcbhcf_x
command = D, DB, B, DB, D, DF, F, x
time = 45

[Command]
name = qcbhcf_y
command = D, DB, B, DB, D, DF, F, y
time = 45

;-| Special Motions |------------------------------------------------------

[Command]
name = qcf_x
command = ~D, F, x
time = 15

[Command]
name = qcf_y
command = ~D, F, y
time = 15

[Command]
name = qcb_x
command = ~D, B, x
time = 15

[Command]
name = qcb_y
command = ~D, B, y
time = 15

[Command]
name = hcb_x
command = ~F, D, B, x
time = 30

[Command]
name = hcb_y
command = ~F, D, B, y
time = 30

[Command]
name = hcb_a
command = ~F, D, B, a
time = 30

[Command]
name = hcb_b
command = ~F, D, B, b
time = 30

[Command]
name = rdp_a
command = ~B, D, DB, a
time = 15

[Command]
name = rdp_b
command = ~B, D, DB, b
time = 15

[Command]
name = qcf_a
command = ~D, F, a
time = 15

[Command]
name = qcf_b
command = ~D, F, b
time = 15

[Command]
name = dp_x
command = ~F, D, DF, x
time = 15

[Command]
name = dp_y
command = ~F, D, DF, y
time = 15

[Command]
name = charge_x
command = ~30$B, F, x
time = 15

[Command]
name = charge_y
command = ~30$B, F, y
time = 15

;-| Double Tap |-----------------------------------------------------------

[Command]
name = FF
command = F, F
time = 10

[Command]
name = BB
command = B, B
time = 10

;-| 2/3 Button Combination |-----------------------------------------------

[Command]
name = recovery
command = x+y
time = 1

[Command]
name = dodge
command = x+y
time = 1

[Command]
name = knockdown
command = a+b
time = 1

[Command]
name = abc
command = a+b+c
time = 1

;-| Dir + Button |---------------------------------------------------------

[Command]
name = fwd_a
command = /F,a
time = 1

[Command]
name = fwd_x
command = /F,x

[Command]
name = back_x
command = /B,x

[Command]
name = fwd_y
command = /F,y

[Command]
name = back_y
command = /B,y

[Command]
name = down_y
command = /D, y

;-| Single Button |---------------------------------------------------------

[Command]
name = a
command = a
time = 1

[Command]
name = hold_a
command = /$a
time = 1

[Command]
name = b
command = b
time = 1

[Command]
name = hold_b
command = /$b
time = 1

[Command]
name = c
command = c
time = 1

[Command]
name = x
command = x
time = 1

[Command]
name = hold_x
command = /$x
time = 1

[Command]
name = y
command = y
time = 1

[Command]
name = hold_y
command = /$y
time = 1

[Command]
name = z
command = z
time = 1

[Command]
name = s
command = s
time = 1

;-| Hold Dir |--------------------------------------------------------------

[Command]
name = holdfwd_x
command = /$F, x
time = 1

[Command]
name = holdfwd_y
command = /$F, y
time = 1

[Command]
name = holdfwd
command = /$F
time = 1

[Command]
name = holdback
command = /$B
time = 1

[Command]
name = holdup
command = /$U
time = 1

[Command]
name = holddown
command = /$D
time = 1

;-|Commands|------------------------------------------------------------------------------

[Statedef -1]

; 182 shiki (SDM)
[State -1]
type = ChangeState
value = 2100
triggerall = command = qcfqcf_x
triggerall = life <= 50
triggerall = power = 3000
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; 182 shiki (SDM)
[State -1]
type = ChangeState
value = 2105
triggerall = command = qcfqcf_y
triggerall = life <= 50
triggerall = power = 3000
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; 182 shiki (DM)
[State -1]
type = ChangeState
value = 2000
triggerall = command = qcfqcf_x
triggerall = power = 3000
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; 182 shiki (DM)
[State -1]
type = ChangeState
value = 2005
triggerall = command = qcfqcf_y
triggerall = power = 3000
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Ura 180 shiki orochi nagi (SDM)
[State -1]
type = ChangeState
value = 2300
triggerall = command = qcbhcf_x
triggerall = power = 3000
triggerall = life < 50
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Ura 180 shiki orochi nagi (SDM)
[State -1]
type = ChangeState
value = 2305
triggerall = command = qcbhcf_y
triggerall = life < 50
triggerall = power = 3000
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Ura 180 shiki orochi nagi (DM)
[State -1]
type = ChangeState
value = 2200
triggerall = command = qcbhcf_x
triggerall = power = 3000
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Ura 180 shiki orochi nagi (DM)
[State -1]
type = ChangeState
value = 2205
triggerall = command = qcbhcf_y
triggerall = power = 3000
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Light 100 shiki oni yaki
[State -1]
type = ChangeState
value = 1500
triggerall = command = dp_x
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Hard 100 shiki oni yaki
[State -1]
type = ChangeState
value = 1520
triggerall = command = dp_y
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; 104 shiki ara gami
[State -1]
type = ChangeState
value = 1000
triggerall = command = qcf_x
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; 128 shiki kuu kizu
[State -1]
type = VarSet
v = 1
value = 1
triggerall = stateno = 1000
triggerall = time > 1
trigger1 = command = qcf_x
trigger2 = command = qcf_y

; Ge shiki migiri ugachi
[State -1]
type = VarSet
v = 1
value = 1
triggerall = stateno = 1005
trigger1 = command = x
trigger2 = command = y

; 127 shiki ya sabi
[State -1]
type = VarSet
v = 1
value = 2
triggerall = stateno = 1000
trigger1 = command = hcb_x
trigger2 = command = hcb_y

; Ge shiki migiri ugachi
[State -1]
type = VarSet
v = 1
value = 1
triggerall = stateno = 1020
trigger1 = command = x
trigger2 = command = y

; 125 shiki nana se
[State -1]
type = VarSet
v = 1
value = 2
trigger1 = stateno = 1005
trigger1 = command = a
trigger2 = stateno = 1005
trigger2 = command = b
trigger3 = stateno = 1020
trigger3 = command = a
trigger4 = stateno = 1020
trigger4 = command = b

; 105 shiki doku gami
[State -1]
type = ChangeState
value = 1300
triggerall = command = qcf_y
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; 401 shiki tsumi yomi
[State -1]
type = VarSet
v = 1
value = 1
triggerall = stateno = 1300
trigger1 = command = qcb_x
trigger2 = command = qcb_y

; 402 shiki batsu yomi
[State -1]
type = VarSet
v = 1
value = 1
triggerall = stateno = 1305
trigger1 = command = holdfwd_x
trigger2 = command = holdfwd_y

; Light 900 shiki nue tsumi
[State -1]
type = ChangeState
value = 1100
triggerall = command = qcb_x
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Hard 900 shiki nue tsumi
[State -1]
type = ChangeState
value = 1105
triggerall = command = qcb_y
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Light 212 shiki kototuki you
[State -1]
type = ChangeState
value = 1200
triggerall = command = hcb_a
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Hard 212 shiki kototuki you
[State -1]
type = ChangeState
value = 1250
triggerall = command = hcb_b
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Light 707 koma ho furi
[State -1]
type = ChangeState
value = 1400
triggerall = command = rdp_a
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Hard 707 koma ho furi
[State -1]
type = ChangeState
value = 1450
triggerall = command = rdp_b
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Light 75 shiki kai
[State -1]
type = ChangeState
value = 1600
triggerall = command = qcf_a
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

;Hard 75 shiki kai
[State -1]
type = ChangeState
value = 1610
triggerall = command = qcf_b
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Light 180 shiki yami barai
[State -1]
type = ChangeState
value = 1700
triggerall = command = charge_x
triggerall = numprojID100 = 0
trigger1 = statetype != A
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Jumping knockdown attack
[State -1]
type = ChangeState
value = 640
triggerall = statetype = A
triggerall = ctrl = 1
trigger1 = command = knockdown
trigger2 = command = c

; Jumping light punch
[State -1]
type = ChangeState
value = 600
trigger1 = command = x
trigger1 = statetype = A
trigger1 = ctrl = 1

; Jumping forward light kick
[State -1]
type = ChangeState
value = 615
trigger1 = command = a
trigger1 = statetype = A
trigger1 = Vel X != 0
trigger1 = ctrl = 1

; Jumping light kick
[State -1]
type = ChangeState
value = 610
trigger1 = command = a
trigger1 = statetype = A
trigger1 = ctrl = 1

; Jumping down + hard punch
[State -1]
type = ChangeState
value = 625
trigger1 = command = down_y
trigger1 = statetype = A
trigger1 = ctrl = 1

; Jumping hard punch
[State -1]
type = ChangeState
value = 620
trigger1 = command = y
trigger1 = statetype = A
trigger1 = ctrl = 1

; Jumping forward hard kick
[State -1]
type = ChangeState
value = 635
trigger1 = command = b
trigger1 = statetype = A
trigger1 = Vel X != 0
trigger1 = ctrl = 1

; Jumping hard kick
[State -1]
type = ChangeState
value = 630
trigger1 = command = b
trigger1 = statetype = A
trigger1 = ctrl = 1

; Crouching light punch
[State -1]
type = ChangeState
value = 400
trigger1 = statetype = C
trigger1 = command = x
trigger1 = ctrl = 1

; Crouching light kick
[State -1]
type = ChangeState
value = 410
trigger1 = statetype = C
trigger1 = command = a
trigger1 = ctrl = 1

; Crouching hard punch
[State -1]
type = ChangeState
value = 420
trigger1 = statetype = C
trigger1 = command = y
trigger1 = ctrl = 1

; Crouching forward hard kick
[State -1]
type = ChangeState
value = 435
triggerall = command = holdfwd
triggerall = command = b
trigger1 = statetype = C
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = command = holddown
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = command = holddown
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = command = holddown
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = command = holddown
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = command = holddown
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = command = holddown
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = command = holddown
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = command = holddown
trigger9 = movehit = 1

; Crouching hard kick
[State -1]
type = ChangeState
value = 430
trigger1 = statetype = C
trigger1 = command = b
trigger1 = ctrl = 1

; Guard cancel roll (backwards)
[State -1]
type = ChangeState
value = 260
triggerall = stateno >= 150
triggerall = stateno =< 151
triggerall = power >= 1500
triggerall = command = holdback
trigger1 = command = dodge
trigger2 = command = z

; Guard cancel roll (forward)
[State -1]
type = ChangeState
value = 250
triggerall = stateno >= 150
triggerall = stateno =< 151
triggerall = power >= 1500
trigger1 = command = dodge
trigger2 = command = z

; Guard cancel attack
[State -1]
type = ChangeState
value = 270
triggerall = stateno >= 150
triggerall = stateno =< 151
triggerall = power >= 1500
trigger1 = command = knockdown
trigger2 = command = c

; Standing knockdown attack
[State -1]
type = ChangeState
value = 240
triggerall = statetype != A
triggerall = ctrl = 1
trigger1 = command = knockdown
trigger2 = command = c

; Standing light punch (close)
[State -1]
type = ChangeState
value = 201
trigger1 = command = x
trigger1 = statetype = S
trigger1 = ctrl = 1
trigger1 = P2bodydist X <= 25

; Standing light punch
[State -1]
type = ChangeState
value = 200
triggerall = command = x
triggerall = command != holddown
trigger1 = statetype = S
trigger1 = ctrl = 1

; Standing hard punch (close)
[State -1]
type = ChangeState
value = 221
trigger1 = command = y
trigger1 = statetype = S
trigger1 = ctrl = 1
trigger1 = P2bodydist X <= 25

; Standing hard punch
[State -1]
type = ChangeState
value = 220
triggerall = command = y
triggerall = command != holddown
trigger1 = statetype = S
trigger1 = ctrl = 1

; Forward light kick
[State -1]
type = ChangeState
value = 215
triggerall = command = fwd_a
triggerall = command != holddown
trigger1 = statetype = S
trigger1 = ctrl = 1
trigger2 = stateno = 200
trigger2 = movehit = 1
trigger3 = stateno = 201
trigger3 = movehit = 1
trigger4 = stateno = 211
trigger4 = movehit = 1
trigger5 = stateno = 221
trigger5 = movehit = 1
trigger6 = stateno = 231
trigger6 = movehit = 1
trigger7 = stateno = 400
trigger7 = movehit = 1
trigger8 = stateno = 420
trigger8 = movehit = 1
trigger9 = stateno = 430
trigger9 = movehit = 1

; Standing light kick (close)
[State -1]
type = ChangeState
value = 211
trigger1 = command = a
trigger1 = statetype = S
trigger1 = ctrl = 1
trigger1 = P2bodydist X <= 25

; Standing light kick
[State -1]
type = ChangeState
value = 210
triggerall = command = a
triggerall = command != holddown
trigger1 = statetype = S
trigger1 = ctrl = 1

; Standing hard kick (close)
[State -1]
type = ChangeState
value = 231
trigger1 = command = b
trigger1 = statetype = S
trigger1 = ctrl = 1
trigger1 = P2bodydist X <= 25

; Standing hard kick
[State -1]
type = ChangeState
value = 230
triggerall = command = b
triggerall = command != holddown
trigger1 = statetype = S
trigger1 = ctrl = 1

; Taunt
[State -1]
type = ChangeState
value = 195
trigger1 = command = s
trigger1 = command != holddown
trigger1 = statetype = S
trigger1 = ctrl = 1

; Run Forward
[State -1]
type = ChangeState
value = 100
trigger1 = command = FF
trigger1 = statetype = S
trigger1 = command != holddown
trigger1 = ctrl = 1

; Run Backwards
[State -1]
type = ChangeState
value = 105
trigger1 = command = BB
trigger1 = statetype = S
trigger1 = command != holddown
trigger1 = ctrl = 1
