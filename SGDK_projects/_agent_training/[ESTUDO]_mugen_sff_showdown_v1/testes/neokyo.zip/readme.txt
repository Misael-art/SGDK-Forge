-- Kyo Kusanagi --

(These files originate from http://ngmc.retrogames.com)

Topics:

* What's this?
* What's needed?
* What's new?
* Comments
* What's done?
* What's left?
* Moveslist
* Credits

-- What's this? --

This is Kyo Kusanagi from The king of fighters '99, adapted for play with
Elecbyte's fighting game engine M.U.G.E.N. by me, NeoGouki (gouki@hem.passagen.se). 

-- What's needed? --

First of all, the newest revision of the M.U.G.E.N. engine which can be found
at http://www.elecbyte.com. Secondly, all the files contained within
the archive neokyo.zip which are:

* neokyo.def
* neokyo.sff
* neokyo.snd
* neokyo.cns
* neokyo.cmd
* neokyo01.act
* neokyo02.act
* neokyo03.act
* neokyo04.act
* neokyo05.act
* neokyo06.act

Unzip all the files into a sub-directory to the directory where you keep the
M.U.G.E.N. engine called "chars\neokyo" and add the character to your
character roster by simply adding the line "neokyo" to your "select.cfg"
under the [Characters] section.

-- What's new? --

Since this documentation is new, everything or nothing, take your pick.

-- Comments --

None at the present.

-- What's done? --

* 3 pre-fight intros
* 3 win poses
* Taunt
* Time over loss animation
* All getting hit, guarding and falling animations
* All required frames
* Running forward, dashing back
* All standing, crouching and jumping normal attacks
* Strike attack
* Guard cancel roll back and forward
* 75 shiki kai
* 100 shiki oni yaki
* 104 shiki ara gami
* 105 shiki doku gami
* 125 shiki nana se
* 127 shiki ya sabi
* 128 shiki kuu kizu
* 180 shiki yami barai
* 212 shiki kototuki you
* 401 shiki tsumi yomi
* 402 shiki batsu yomi
* 707 koma ho furi
* 910 shiki nue tsumi
* Ge shiki migiri ugachi
* 182 shiki
* Ura 180 shiki orochi nagi

-- What's left? --

* Intros vs. K' and Benimaru
* Hard Yami barai
* Mu shiki
* Explosions and other effects

-- Moveslist --

  Light punch
        - X
  Light kick
        - A
  Hard punch
        - Y
  Hard kick
        - B
  Taunt
        - Start
  Ge shiki naraku otoshi
        - D + Y
        - In the air
  Ge shiki gou fu you
        - F + A
  88 shiki
        - DF + B
        - Crouching
  Strike attack
        - C / Y + B
        - Can also be done in the air
  Guard cancel roll
        - F or B + Z / X + A
        - While guarding
        - Power level at 1500 or higher
  Guard cancel attack
        - C / Y + B
        - While guarding
        - Power level at 1500 or higher
  100 shiki oni yaki
        - F, D, DF + X or Y
  104 shiki ara gami
        - D, DF, F + X
  128 shiki kuu kizu
        - D, DF, F + X or Y
        - During Shiki ara gami
  127 shiki ya sabi
        - F, DF, D, DB, B + X or Y
        - During Shiki ara gami
  Ge shiki migiri ugachi
        - X or Y
        - During Shiki kuu kizu or Shiki ya sabi
  125 shiki nana se
        - A or B
        - During Shiki kuu kizu or Shiki ya sabi
  105 shiki doku gami
        - D, DF, F + Y
  401 shiki tsumi yomi
        - F, DF, D, DB, B + X or Y
        - During Shiki doku gami
  402 shiki batsu yomi
        - F + X or Y
        - During Shiki tsumi yomi
  180 shiki yami barai
        - Charge B, F + X
  212 shiki kototuki you
        - F, DF, D, DB, B + A or B
  707 koma ho furi
        - B, D, DB + A or B
  910 shiki nue tsumi
        - D, DB, B + X or Y
  182 shiki
        - D, DF, F, D, DF, F + X or Y
        - Power level at 3000
        - Turns into SDM version when life equals or is lower than 50
        - Hold button to charge move
  Ura 180 shiki orochi nagi
        - D, DB, B, DB, D, DF, F + X or Y
        - Power level at 3000
        - Turns into SDM version when life equals or is lower than 50
        - Hold button to delay move

-- Credits --

* SNK, for making the much credited King of fighters series so that I had something to steal from.
* I have to credit myself of course, for taking the time to convert
  this character to the M.U.G.E.N. format.
* Elecbyte, for creating the wonderful M.U.G.E.N. engine and letting us experience
  the match-ups of our dreams.
* TESTP, for being a great support in the everyday struggle of character making
  and being nice guys in general.
* All the great guys and girls over at the TESTP message board who can be a
  great resource from time to time.