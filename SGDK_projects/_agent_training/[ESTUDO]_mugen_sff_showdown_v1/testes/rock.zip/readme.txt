-- Rock Howard --

(These files originate from http://ngmc.retrogames.com)

Topics:

* What's this?
* What's needed?
* What's new?
* Comments
* What's done?
* What's left?
* Moveslist
* Credits

-- What's this? --

This is Rock Howard from Garou: Mark of the wolves, adapted for play with
Elecbyte's fighting game engine M.U.G.E.N. by me, NeoGouki (gouki@hem.passagen.se). 

-- What's needed? --

First of all, the newest revision of the M.U.G.E.N. engine which can be found
at http://www.elecbyte.com. Secondly, all the files contained within
the archive rock.zip which are: 

* rock.def
* rock.sff
* rock.snd
* rock.cns
* rock.cmd
* rock01.act
* rock02.act
* rock03.act
* rock04.act

Unzip all the files into a sub-directory to the directory where you keep the
M.U.G.E.N. engine called "chars\rock" and add the character to your
character roster by simply adding the line "rock" to your "select.cfg"
under the [Characters] section.

-- What's new? --

* Added the "NoWalk" flag to the running state so that Rock can run properly.
* Made stage foreground layers disappear during super pauses.

-- Comments --

The hit sparks aren't 100% true to the original since most of them are divided up into two parts,
one that goes in front of the opponent and one behind. Therefore I have used the sparks
where I found they fit.

-- What's done? --

* 2 pre-fight intros
* 4 win poses
* Taunt
* Time over loss animation
* Time over draw animation
* All getting hit, guarding and falling animations
* All required frames
* Running forward, dashing back
* All standing, crouching and jumping normal attacks
* Safe landings
* Dodge attacks
* TOP mode
* TOP attack
* "Just defend"
* Throws
* Reppuken/Double Reppuken
* Rising tackle
* Hard edge
* Rage run: type "dunk"/type "shift"
* Crack counter jou-dan/ge-dan
* Shinkuu nage
* Rassetsu
* Raging storm
* Shine knuckle
* Deadly rave neo
* Fakeouts

-- What's left? --

Nothing...?

-- Moveslist --

  Light punch
        - X
  Light kick
        - A
  Hard punch
        - Y
  Hard kick
        - B
  Taunt
        - Start
  Kokuu sen (throw)
        - F + Y
        - Close to the opponent
  Dodge attack A
        - C / X + A
  Dodge attack B
        - C / X + A
        - Crouching
  TOP attack
        - C / Y + B
        - While in TOP mode
  Safe landing
        - Press X or Y for short/long forward roll
        - Press A or B for short/long backwards roll
        - Just before you hit the ground
  Reppuken/Double Reppuken
        - D, DF, F + X or Y
  Rising tackle
        - Charge D, U + X or Y
  Hard edge
        - D, DB, B + X or Y
  Rage run: type "dunk"/"shift"
        - D, DB, B + A or B
  Crack counter jou-dan/ge-dan
        - D, DF, F + A or B
  Shinkuu nage [BR]
        - A 360 degree motion in any direction + Y
        - Close to the opponent
        - To brake the motion, quickly press C / X + A
  Rassetsu
        - Keep holding C / X + A after braking Shinkuu nage
  S. Raging storm
        - D, DF, F, D, DF, F + X
        - Power level at 1000 or higher
  P. Raging storm
        - D, DF, F, D, DF, F + Y
        - Power level at 2000 or higher
  S. Shine knuckle
        - D, DF, F, D, DF, F + A
        - Power level at 1000 or higher
  P. Shine knuckle
        - D, DF, F, D, DF, F + B
        - Power level at 2000 or higher
  Deadly rave neo
        - F, DF, D, DB, B, F + X
        - Power level at 2000 or higher
        - Follow with X, X, A, A, Y, Y, B, B, D, DB, B + Y
  Fake Shine knuckle
        - F + A + Y (at the same time)
  Fake Reppuken
        - D + A + Y (at the same time) 

Quick explanation of the TOP system and "just defend":

When you select Rock as your character you can choose from three various TOP modes,
each activating when Rock's life is within the specified range. Pressing X or A will
select TOP A (life range 1000-750), pressing Y or B will select TOP B (life range 625-375)
and pressing Z or C will select TOP C (life range 250-0). Whenever Rock's life is within
the specified range, his offensive power will increase, he can use the TOP attack and
his life will slowly recover with time (but will never go past the maximum value for
the TOP mode you've chosen).

As for the "just defend" system, by defending at just the moment before the impact of
the opponent's move will recover a bit of life as well as enable you to cancel your guard
and retaliate with a move of your own.

-- Credits --

* SNK, for making Garou: MoTW, the most insanely animated game on NEO-GEO.
* I have to credit myself of course, for taking the time to convert
  this character to the M.U.G.E.N. format.
* Elecbyte, for creating the wonderful M.U.G.E.N. engine and letting us experience
  the match-ups of our dreams.
* TESTP, for being a great support in the everyday struggle of character making
  and being nice guys in general.
* All the great guys and girls over at the TESTP message board who can be a
  great resource from time to time.