-- Forest in bloom --

(These files originate from http://ngmc.retrogames.com)

Topics: 

* What's this?
* What's needed?
* What's new?
* Comments
* Credits

-- What's this? --

This is the stage "Forest in bloom" from Samurai shodown 4,
adapted for play with Elecbyte's fighting game engine M.U.G.E.N. by me,
NeoGouki (gouki@hem.passagen.se).

-- What's needed? --

First of all, the newest revision of the M.U.G.E.N. engine which can be found at
http://www.elecbyte.com. Secondly, all the files contained within the archive
bloom.zip which are:

* bloom.def 
* bloom.sff 

Unzip all the files into the "stages" sub-directory of the directory where you
keep the M.U.G.E.N. engine. Add the stage to your list of playable stages by
opening up "select.cfg" and simply add the line "bloom", either under the section of
"extra" stages or as a character specific stage.

-- What's new? --

Updated this stage for compatibility with MUGEN 06 27.

-- Comments --

None at the present.

-- Credits --

* SNK, for making some of the greatest video game art ever.
* I have to credit myself of course, for taking the time to convert this stage to
  the M.U.G.E.N. format.
* Elecbyte, for creating the wonderful M.U.G.E.N. engine and letting us experience
  the match-ups of our dreams.
* TESTP, for being a great support in the everyday struggle of character making
  and being nice guys in general.
* All the great guys and girls over at the TESTP message board who can be a great
  resource from time to time.