--- Joe Higashi ---

(These files originate from http://ngmc.retrogames.com)

Topics:

* What's this?
* What's needed?
* What's new?
* Comments
* What's done?
* What's left?
* Moveslist
* Credits

--- What's this? ---

This is Joe Higashi from Real bout Fatal fury special and Real bout Fatal fury 2,
adapted for play with Elecbyte's fighting game engine M.U.G.E.N. by me,
NeoGouki (gouki@hem.passagen.se).

--- What's needed? ---

First of all, the newest revision of the M.U.G.E.N. engine which can be found
at http://www.elecbyte.com. Secondly, all the files contained within
the archive joe.zip which are:

* joe.def
* joe.sff
* joe.snd
* joe.cns
* joe.cmd
* joe01.act
* joe02.act
* joe03.act
* joe04.act
* joe05.act

Unzip all the files into a sub-directory to the directory where you keep the
M.U.G.E.N. engine called "chars\joe" and add the character to your
character roster by simply adding the line "joe" to your "select.cfg"
under the [Characters] section.

--- What's new? ---

* Added missing action 5090.
* Changed super format. There is no longer a "low on life" limit for the supers.
  The supers have also switched commands (check the moveslist).
* Removed the super pause and BG from the Slide Screw (it just didn't fit).
* Some general re-coding.

--- Comments ---

None at the present.

--- What's done? ---

* 3 pre-fight intros
* 5 win poses
* 2 taunts
* Time over loss animation
* All getting hit, guarding and falling animations
* All required frames
* Dashing forward and back
* All standing, crouching and jumping normal attacks
* Two throws
* Hurricane upper
* Exploding hurricane
* Golden heel
* Tiger kick
* Bakuretsu punch + follow-ups
* Slash kick
* Pressure knee + follow-up
* Screw upper
* Slide screw
* Thunder fire

--- What's left? ---

Nothing...?

--- Moveslist ---

  Light attack
        - A
  Medium attack
        - B
  Hard attack
        - C
  Arial turning
        - Y
  High elbow
        - df + A
        - Crouching
  Uppercut
        - b + A
  Roundhouse
        - b + B
  Slide kick
        - df + B
        - Crouching
  Taunt
        - C
        - Far away from the opponent, standing still
  Extra taunt
        - d + C
        - When the opponent is lying down
  Knee kick combo
        - f + C
        - Close to the opponent
  Knee bash
        - df + C
        - Close to the opponent
  Heel kick
        - Hold down
        - After successfully hitting with the Knee kick combo
  Hurricane upper
        - f, df, d, db, b + A
  Fake Hurricane upper
        - b + A + B
  Exploding hurricane
        - f, df, d, db, b + C
  Golden heel
        - d, db, b + B
  Tiger kick
        - f, d, df + B
  Fake Tiger kick
        - d + A + B
  Pressure knee
        - f, d, df + C
  Pressure knee follow-up
        - d, db, b + B
        - After connecting with the Pressure knee
  Bakuretsu punch
        - Rapidly press A
  Bakuretsu hook
        - d, df, f + A
        - During Bakuretsu punch
  Bakuretsu uppercut
        - d, df, f + C
        - During Bakuretsu punch
  Slash kick
        - db, f + A or C
  Screw upper
        - f, b, db, d, df + BC
        - With power at level 1 or higher
  Slide screw
        - f, b, db, d, df + B
        - With power at level 2 or higher
  Thunder fire
        - f, b, db, d, df + C
        - With power at level 2 or higher

-- Combo chart --

  A --->   B --->   C / DF + C
     |        V
(C)A --> (C)B --> (C)C / DF + C

  B --->   B --->   C / DF + C
              V
(C)B --> (C)B --> (C)C / DF + C

B ---> C ---> C ---> QCF + C

A ---> C

B + A ---> C ---> C ---> C ---> F + C

(Specials can be tagged onto virtually any move
 that doesn't knock the opponent down)

--- Credits ---

* SNK, for making Real bout Fatal fury special, one of the IMHO best fighting games.
* I have to credit myself of course, for taking the time to convert
  this character to the M.U.G.E.N. format.
* Elecbyte, for creating the wonderful M.U.G.E.N. engine and letting us experience
  the match-ups of our dreams.
* TESTP, for being a great support in the everyday struggle of character making
  and being nice guys in general.