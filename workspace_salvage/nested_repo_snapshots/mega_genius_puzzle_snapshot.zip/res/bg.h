#ifndef _RES_BG_H_
#define _RES_BG_H_

extern const SpriteDefinition yelow;
extern const SpriteDefinition blue;
extern const SpriteDefinition green;
extern const SpriteDefinition red;
extern const Image bgb;

#endif // _RES_BG_H_
