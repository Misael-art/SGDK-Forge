IMAGE bgb "bgx\bgb.bmp" BEST
SPRITE yelow "bgx\corneta amarela.png" 12 12 NONE 12
SPRITE blue "bgx\guitarra azul.png" 12 12 NONE 12
SPRITE green "bgx\piano verde.png" 12 6 NONE 12
SPRITE red "bgx\tambor vermelho.png" 12 12 NONE 12
