#ifndef _RES_SOUND_H_
#define _RES_SOUND_H_

extern const u8 guitar_snd[142848];
extern const u8 piano_snd[67328];
extern const u8 sax_snd[44544];
extern const u8 drum_snd[38400];
extern const u8 gameover_snd[95488];

#endif // _RES_SOUND_H_
