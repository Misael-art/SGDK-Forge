
WAV guitar_snd "sound\guitarra.wav" PCM 32000
WAV piano_snd  "sound\piano.wav" PCM 32000
WAV sax_snd    "sound\sax.wav" PCM 32000
WAV drum_snd   "sound\tambor.wav" PCM 32000
WAV gameover_snd   "sound\game-over.wav" PCM 32000
