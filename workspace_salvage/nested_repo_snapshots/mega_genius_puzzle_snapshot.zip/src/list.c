/**
 * @file list.c
 * @author Paulo Linhares
 * @brief 
 * @version 0.1
 * @date 2022-09-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "list.h"


void List_init()
{
    listHead = NULL;
}


u8 List_insert(Colors color)
{
    List *p;

    p = (List *)MEM_alloc(sizeof(List));
    if (p == NULL)
    {
        // erro on allocation
        return 0;
    }
    p->color = color;
    p->next = NULL;

    if (listHead == NULL)
        listHead = p;
    else
    {
        List *current = listHead;
        while ( current->next != NULL)
        {
            current = current->next;
        }
        current->next = p;
    }
    return 1;
}

u16 List_size()
{
    u16 size = 0;

    if (listHead == NULL)
        return 0;
    List *ptr = listHead;
    for (size = 0; ptr != NULL; size++)
    {
        ptr = ptr->next;
    }
    
    return size;

}


void List_clear()
{
    for (List *ptr = listHead; ptr != NULL; ptr = listHead)
    {
        listHead = listHead->next;
        MEM_free(ptr);
    }
}