/**
 * @file list.h
 * @author Paulo Linhares
 * @brief 
 * @version 0.1
 * @date 2022-09-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "genesis.h"

#ifndef __LIST__
#define __LIST__



typedef enum
{
    RED,
    YELOW,
    GREEN,
    BLUE,
    NONE
}Colors;

typedef struct list
{
    Colors color;
    struct list *next;
}List;

List *listHead;


/**
 * @brief Init list struct
 * 
 */
void List_init();

/**
 * @brief insert a node in the list
 * 
 * @param color the color of next node
 * @return 1 if node was insert and 0 if fail
 */
u8 List_insert(Colors color);

/**
 * @brief get list size
 * 
 * @return u16 list size
 */
u16 List_size();

/**
 * @brief clear the list
 * 
 */
void List_clear();

#endif