/**
 * @file main.c
 * @author Paulo linhares
 * @brief 
 * @version 0.1
 * @date 2022-08-31
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <genesis.h>
#include "bg.h"
#include "sound.h"
#include "list.h"

// Este jogo funciona como um "Simon Says" musical:
// o computador toca uma sequencia de cores e o jogador precisa repeti-la.
// O loop principal alterna entre duas fases: demonstracao da sequencia e resposta do jogador.

int main()
{
    u32 frame, lastFrame; //frame conters
    SPR_init(); //init sprite engine
    u16 palRed[16]; //array to store red pal
    u16 palYelow[16]; //array to store yelow pal
    u16 palGreen[16]; //array to store green pal
    u16 palBlue[16];  //array to store blue pal
    u16 sqares[4] = {RGB24_TO_VDPCOLOR(0xff0000),RGB24_TO_VDPCOLOR(0x00ff00), RGB24_TO_VDPCOLOR(0x0000ff), RGB24_TO_VDPCOLOR(0xffff00)}; // store colors to draw retangles

    // create one color palets
    memsetU16(palRed, sqares[0],16);
    memsetU16(palYelow, sqares[3],16);
    memsetU16(palGreen, sqares[1],16);
    memsetU16(palBlue, sqares[2],16);

    //load palets
    PAL_setColors(1,sqares,4,DMA_QUEUE);
    PAL_setColor(15,RGB24_TO_VDPCOLOR(0xcfcfcf));
    PAL_setPalette(PAL1, red.palette->data, DMA_QUEUE);
    PAL_setPalette(PAL2, green.palette->data, DMA_QUEUE);
    PAL_setPalette(PAL3, blue.palette->data, DMA_QUEUE);

    Sprite *piano, *drum, *corneta, *guitar;
    // create struments sprites
    drum = SPR_addSprite(&red, 48, 112, TILE_ATTR(PAL1, FALSE, FALSE, FALSE));
    corneta = SPR_addSprite(&yelow, 168, 28, TILE_ATTR(PAL1, FALSE, FALSE, FALSE));
    piano = SPR_addSprite(&green, 48, 48, TILE_ATTR(PAL2, FALSE, FALSE, FALSE));
    guitar = SPR_addSprite(&blue, 168, 120, TILE_ATTR(PAL3, FALSE, FALSE, FALSE));

    // hide struments
    SPR_setVisibility(drum, HIDDEN);
    SPR_setVisibility(corneta, HIDDEN);
    SPR_setVisibility(piano, HIDDEN);
    SPR_setVisibility(guitar, HIDDEN);

    // draw retangles 
    VDP_fillTileMapRect(BG_B,TILE_ATTR_FULL(PAL0,FALSE,FALSE,FALSE,1),5,15,14,12); //draw red rectangle
    VDP_fillTileMapRect(BG_B,TILE_ATTR_FULL(PAL0,FALSE,FALSE,FALSE,4),20,4,14,10); //draw yelow rectangle
    VDP_fillTileMapRect(BG_B,TILE_ATTR_FULL(PAL0,FALSE,FALSE,FALSE,2),5,4,14,10); //draw green rectangle
    VDP_fillTileMapRect(BG_B,TILE_ATTR_FULL(PAL0,FALSE,FALSE,FALSE,3),20,15,14,12); //draw blue rectangle

    // draw buttons of each retangle
    VDP_drawText("Start", 9, 4);
    VDP_drawText("A", 27, 4);
    VDP_drawText("B", 12, 15);
    VDP_drawText("C", 27, 15);

    // Estas flags controlam em que etapa do turno o jogo esta.
    // "seq" aponta para o passo atual da sequencia; quando chega ao fim, passa a vez ao jogador.
    // "player_doing" indica se a memoria agora esta sendo testada no controle.
    // "fade_in" e "fade_out" sincronizam audio, sprite e destaque visual de cada cor.
    // init game variables
    bool start = FALSE;
    bool fade_in = FALSE;
    bool fade_out = FALSE;
    bool player_doing = FALSE;
    Colors player_correct = NONE;
    u32 score = 0;
    
    //init list of game sequency
    List_init();

    //init list of sequency
    List *seq = NULL;

    // text to init game
    VDP_drawText("press start to init", 10, 1);

    // A cada frame o jogo decide se esta mostrando a sequencia ou esperando a repeticao.
    while(1)
    {
        frame++;    //increment frame counter

        u16 key = JOY_readJoypad(JOY_1);   // read joypad

        if(start == TRUE) //test if game has started
        {
            
            // Enquanto ainda houver nos na lista e o jogador nao estiver respondendo,
            // a maquina "toca" cada cor da sequencia uma por vez.
            if(seq != NULL && player_doing == FALSE) // test if is the game playing or user
            {        
                switch (seq->color)
                {
                case RED:
                    if(fade_in == FALSE && fade_out == FALSE) //test if is fading
                    {
                        KLog("fade in");
                        SPR_setVisibility(drum, VISIBLE);
                        PAL_fade(16, 31, palRed, red.palette->data,  60, TRUE); //init fade in
                        SND_startPlay_PCM(drum_snd, sizeof(drum_snd), SOUND_RATE_32000, SOUND_PAN_CENTER , 0); //play instrument sound
                        fade_in = TRUE;
                        lastFrame = frame;
                    }
                    if((frame - lastFrame) == 60 && fade_in == TRUE)
                    {
                        KLog("fade out");
                        PAL_fade(16, 31, red.palette->data, palRed, 60, TRUE); // init fade out
                        fade_in = FALSE;
                        fade_out = TRUE;
                        lastFrame = frame;
                    }
                    break;
                case YELOW:
                    if(fade_in == FALSE && fade_out == FALSE)
                    {
                        KLog("fade in");
                        SPR_setVisibility(corneta, VISIBLE);
                        PAL_fade(16, 31, palYelow, yelow.palette->data,  60, TRUE);
                        SND_startPlay_PCM(sax_snd, sizeof(sax_snd), SOUND_RATE_32000, SOUND_PAN_CENTER , 0);
                        fade_in = TRUE;
                        lastFrame = frame;
                    }
                    if((frame - lastFrame) == 60 && fade_in == TRUE)
                    {
                        KLog("fade out");
                        PAL_fade(16, 31, yelow.palette->data, palYelow, 60, TRUE);
                        fade_in = FALSE;
                        fade_out = TRUE;
                        lastFrame = frame;
                    }
                    break;
                case GREEN:
                    if(fade_in == FALSE && fade_out == FALSE)
                    {
                        KLog("fade in");
                        SPR_setVisibility(piano, VISIBLE);
                        PAL_fade(32, 47, palGreen, green.palette->data,  60, TRUE);
                        SND_startPlay_PCM(piano_snd, sizeof(piano_snd), SOUND_RATE_32000, SOUND_PAN_CENTER , 0);
                        fade_in = TRUE;
                        lastFrame = frame;
                    }
                    if((frame - lastFrame) == 60 && fade_in == TRUE)
                    {
                        KLog("fade out");
                        PAL_fade(32, 47, green.palette->data, palGreen, 60, TRUE);
                        fade_in = FALSE;
                        fade_out = TRUE;
                        lastFrame = frame;
                    }
                    break;
                case BLUE:
                    if(fade_in == FALSE && fade_out == FALSE)
                    {
                        KLog("fade in");
                        SPR_setVisibility(guitar, VISIBLE);
                        PAL_fade(48, 63, palBlue, blue.palette->data,  60, TRUE);
                        SND_startPlay_PCM(guitar_snd, sizeof(guitar_snd), SOUND_RATE_32000, SOUND_PAN_CENTER , 0);
                        fade_in = TRUE;
                        lastFrame = frame;
                    }
                    if((frame - lastFrame) == 60 && fade_in == TRUE)
                    {
                        KLog("fade out");
                        PAL_fade(48, 63, blue.palette->data, palBlue, 60, TRUE);
                        fade_in = FALSE;
                        fade_out = TRUE;
                        lastFrame = frame;
                    }
                    break;
                
                default:
                    break;
                }
                
                if((frame - lastFrame) == 60 && fade_out == TRUE) // test if fade out has finished
                {
                    fade_out = FALSE;
                    SPR_setVisibility(drum, HIDDEN);
                    SPR_setVisibility(corneta, HIDDEN);
                    SPR_setVisibility(piano, HIDDEN);
                    SPR_setVisibility(guitar, HIDDEN);
                    seq = seq->next;    // go to the next node of list
                }
            }
            // Quando a sequencia termina, o mesmo fluxo de fade e som passa a validar a resposta do jogador.
            else // player needs to repeat sequency
            {
                if(player_doing == FALSE)
                {
                    KLog("player doing");
                    player_doing = TRUE;
                    seq = listHead;
                    fade_in = FALSE;
                    fade_out = FALSE;
                    player_correct = NONE;
                    VDP_clearTextLine(2);
                    VDP_drawText("your time to repeat", 10, 2);
                }
                else
                {
                    if(player_correct == NONE)
                    {

                        if((key & BUTTON_START) && seq->color == GREEN)
                        {
                            if(fade_in == FALSE && fade_out == FALSE)
                            {
                                KLog("fade in start");
                                SPR_setVisibility(piano, VISIBLE);
                                PAL_fade(32, 47, palGreen, green.palette->data,  60, TRUE);
                                SND_startPlay_PCM(piano_snd, sizeof(piano_snd), SOUND_RATE_32000, SOUND_PAN_CENTER , 0);
                                fade_in = TRUE;
                                player_correct = GREEN;
                                lastFrame = frame;
                            }
                        }
                        else if((key & BUTTON_A) && seq->color == YELOW)
                        {
                            if(fade_in == FALSE && fade_out == FALSE)
                            {
                                KLog("fade in A");
                                SPR_setVisibility(corneta, VISIBLE);
                                PAL_fade(16, 31, palYelow, yelow.palette->data,  60, TRUE);
                                SND_startPlay_PCM(sax_snd, sizeof(sax_snd), SOUND_RATE_32000, SOUND_PAN_CENTER , 0);
                                fade_in = TRUE;
                                player_correct = YELOW;
                                lastFrame = frame;
                            }
                        }
                        else if((key & BUTTON_B) && seq->color == RED)
                        {
                            if(fade_in == FALSE && fade_out == FALSE)
                            {
                                KLog("fade in B");
                                SPR_setVisibility(drum, VISIBLE);
                                PAL_fade(16, 31, palRed, red.palette->data,  60, TRUE);
                                SND_startPlay_PCM(drum_snd, sizeof(drum_snd), SOUND_RATE_32000, SOUND_PAN_CENTER , 0);
                                fade_in = TRUE;
                                player_correct = RED;
                                lastFrame = frame;
                            }
                            
                        }
                        else if((key & BUTTON_C) && seq->color == BLUE)
                        {
                            if(fade_in == FALSE && fade_out == FALSE)
                            {
                                KLog("fade in C");
                                SPR_setVisibility(guitar, VISIBLE);
                                PAL_fade(48, 63, palBlue, blue.palette->data,  60, TRUE);
                                SND_startPlay_PCM(guitar_snd, sizeof(guitar_snd), SOUND_RATE_32000, SOUND_PAN_CENTER , 0);
                                fade_in = TRUE;
                                player_correct = BLUE;
                                lastFrame = frame;
                            }
                        }
                        else if(key & BUTTON_BTN)
                        {
                            start = FALSE;
                            VDP_clearTextLine(2);
                            VDP_drawText("Game over press start to reinit", 4, 2);
                            SND_startPlay_PCM(gameover_snd, sizeof(gameover_snd), SOUND_RATE_32000, SOUND_PAN_CENTER , 0);
                            List_clear();
                        }
                    }
                    else
                    {
                        if( player_correct == RED)
                        {
                            if((frame - lastFrame) == 60 && fade_in == TRUE)
                            {
                                KLog("fade out");
                                PAL_fade(16, 31, red.palette->data, palRed, 60, TRUE);
                                fade_in = FALSE;
                                fade_out = TRUE;
                                lastFrame = frame;
                            }
                        }
                        else if(player_correct == BLUE)
                        {
                            if((frame - lastFrame) == 60 && fade_in == TRUE)
                            {
                                KLog("fade out");
                                PAL_fade(48, 63, blue.palette->data, palBlue, 60, TRUE);
                                fade_in = FALSE;
                                fade_out = TRUE;
                                lastFrame = frame;
                            }
                        }
                        else if(player_correct == GREEN)
                        {
                            if((frame - lastFrame) == 60 && fade_in == TRUE)
                            {
                                KLog("fade out");
                                PAL_fade(32, 47, green.palette->data, palGreen, 60, TRUE);
                                fade_in = FALSE;
                                fade_out = TRUE;
                                lastFrame = frame;
                            }
                        }
                        else if(player_correct == YELOW)
                        {
                            if((frame - lastFrame) == 60 && fade_in == TRUE)
                            {
                                KLog("fade out");
                                PAL_fade(16, 31, yelow.palette->data, palYelow, 60, TRUE);
                                fade_in = FALSE;
                                fade_out = TRUE;
                                lastFrame = frame;
                            }
                        }
                    }
                    if((frame - lastFrame) == 60 && fade_out == TRUE)
                    {
                        fade_out = FALSE;
                        SPR_setVisibility(drum, HIDDEN);
                        SPR_setVisibility(corneta, HIDDEN);
                        SPR_setVisibility(piano, HIDDEN);
                        SPR_setVisibility(guitar, HIDDEN);
                        seq = seq->next;
                        player_correct = NONE;
                    }
                    if(seq == NULL)
                    {
                        score ++;
                        KLog("end of sequence player doing");
                        player_doing = FALSE;
                        seq = listHead;
                        List_insert(random() % 4);

                        char text[32];
                        sprintf(text,"score %d", score);
                        VDP_drawText(text, 16, 1);
                        VDP_clearTextLine(2);
                        VDP_drawText("your time to listen", 10, 2);
                        waitMs(1000);
                    }
                }
                
            }
        }
        else
        {
            if(key & BUTTON_START && !SND_isPlaying_PCM()) // test if start  key has pressed
            {
                score = 0;
                fade_in = FALSE;
                fade_out = FALSE;
                player_correct = NONE;
                player_doing = FALSE;
                KLog("start pressed");
                start = TRUE;
                setRandomSeed(frame);
                List_insert(random() % 4);
                seq = listHead;
                KLog_U2("color: ", seq->color, " next ", seq->next);
                char text[32];
                
                sprintf(text,"score %d", score);
                VDP_clearTextLine(1);
                VDP_clearTextLine(2);
                VDP_drawText(text, 16, 1);
                VDP_drawText("listen to repeat", 10, 2);
            }
        }

        SPR_update();
        SYS_doVBlankProcess();
    }
    return (0);
}
