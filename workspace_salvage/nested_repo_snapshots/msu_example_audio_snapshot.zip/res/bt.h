#ifndef _RES_BT_H_
#define _RES_BT_H_

extern const SpriteDefinition kaizer2;
extern const SpriteDefinition krauzer;
extern const SpriteDefinition krauzer0;
extern const SpriteDefinition spr_kim_121;

#endif // _RES_BT_H_
