#ifndef _RES_SOUND_H_
#define _RES_SOUND_H_

extern const u8 error_sfx[24064];
extern const u8 click_sfx[24064];
extern const u8 sonic_music[21760];
extern const u8 back_music[86016];
extern const u8 sor_music[27392];
extern const u8 guile_music[105472];
extern const u8 zelda_music[11008];
extern const u8 castle_music[79360];
extern const u8 topGear_music[111616];
extern const u8 ateredBeast_music[55552];
extern const u8 smooth_music[64768];
extern const u8 phantasy_music[48384];

#endif // _RES_SOUND_H_
