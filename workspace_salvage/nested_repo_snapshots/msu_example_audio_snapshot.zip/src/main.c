
// *****************************************************************************
//  Scaling Example
//
//  Written in 2021 by Andreas Dietrich
// *****************************************************************************

// -----------------------------------------------------------------------------
//  Includes
// -----------------------------------------------------------------------------

// SGDK
#include <genesis.h>

// Resources
#include "bg.h"
#include "bt.h"

// *****************************************************************************
//
//  Subroutines
//
// *****************************************************************************
u16 msu_drv();

vu16 *mcd_cmd = (vu16 *) 0xA12010;
vu32 *mcd_arg = (vu32 *) 0xA12012;
vu8 *mcd_cmd_ck = (vu8 *) 0xA1201F;
vu8 *mcd_stat = (vu8 *) 0xA12020;

// -------------------------------------------------------------------------
//  Interrupt handlers
// -------------------------------------------------------------------------

static vu16  lineDisplay   = 0;             // line position on display screen
static vfix16 lineGraphics = 1;             // line position in graphics texture
static fix16 scroll        = 0;             // scrolling offset
static vfix16 scale        = FIX16(6.0);    // scaling factor
static vu16 color = 0;

const u16 colors[] = {36, 38, 40, 42, 44, 46, 78, 110, 142, 174, 206, 238, 236, 234, 232, 230, 228, 226, 224, 736, 1248, 1760, 2272, 2784, 3296, 3808, 3810, 3812};

HINTERRUPT_CALLBACK HIntHandler()
{
    PAL_setColor(6, colors[lineGraphics++]);
    
}

void VBlankHandler()
{
    // Reset to line 0
   lineGraphics = 0;
 }

// *****************************************************************************
//
//  Main
//
// *****************************************************************************

int main()
{

    u8 loop = 1;
    u8 track = 1;
    u16 play_cmd;
    u16 resp;
    u8 seek_delay_off = 0;
    u8 loop_offset = 0;
    //
    // Initalization
    //

    // Setup VDP

    // Setup graphics

    // Setup interrupt handlers
    SYS_disableInts();
    {
        SYS_setVBlankCallback(VBlankHandler);
        SYS_setHIntCallback(HIntHandler);
        // VDP_setHIntCounter(7);
        // VDP_setHInterrupt(1);
        SPR_init();
    }
    SYS_enableInts();

    VDP_loadTileSet(bg_musica.tileset, 1, DMA);
    VDP_setTileMapEx(BG_B, bg_musica.tilemap,TILE_ATTR_FULL(PAL0, 0,0,0,1), 0,0,0,0, 40,28,DMA_QUEUE);
    PAL_setPalette(PAL0, bg_musica.palette->data, DMA_QUEUE);
    //
    // Display loop
    //
    u32 frame = 0;
    bool sprite_add = TRUE;
    Sprite *k0;


    resp = msu_drv();
    if (resp) {
        VDP_drawText("err",0,0);
        VDP_drawText("MCD hardware not detected",0,1);
        while (1);
    }

    VDP_drawText("ok  ", 0,2);
    VDP_drawText("init driver..          ", 0,3);
    while (*mcd_stat != 1);
    VDP_drawText("waiting...",0,4 );
    while (*mcd_stat == 1); //wait till sub cpu finis initialization
    VDP_drawText("ok", 0,5);
    VDP_clearTextArea(0,0,40,6);
    char text[32];

    while (TRUE)
    {

        
        VDP_drawText("track:",0,0);
        
        intToStr(track, text, 2);
        VDP_drawText(text, 7,0);
        VDP_drawText("loop:",0,1);
        VDP_drawText(loop ? "ON " : "OFF",7,1);
        VDP_drawText("seek delay:", 0,2);
        VDP_drawText(seek_delay_off ? "OFF" : "ON ", 13,2);
        VDP_drawText("loop offset:", 0,3);
        VDP_drawText(loop_offset == 0 ? "OFF" : "ON ", 13, 3);

        
        VDP_drawText("SWITCH TRACK (LEFT/RIGHT)",0,23);
        VDP_drawText("CHANGE LOOP MODE (START)",0,24);
        VDP_drawText("PALY(A) PAUSE(B) RESUME(C)",0,25);
        VDP_drawText("SEEK DELAY (UP)",0,26);
        VDP_drawText("LOOP OFFSET (DOWN)",0,27);

        play_cmd = loop ? (loop_offset ? 0x1A00 : 0x1200) : 0x1100;
        u16 joy = JOY_readJoypad(JOY_1);
        
        if (joy & BUTTON_LEFT && track > 1) {
            track--;
            waitMs(500);
        }

        if (joy & BUTTON_RIGHT && track < 99) {
            track++;
            waitMs(500);
        }

        if (joy & BUTTON_A) {
            *mcd_cmd = play_cmd | track;
            *mcd_arg = 12 * 75; //loop offset (12 sec in this sample). Used only for cmd 0x1A00
            *mcd_cmd_ck = *mcd_cmd_ck + 1;
            waitMs(500);
        }

        if (joy & BUTTON_B) {
            *mcd_cmd = 0x1300 | 75; //one sec fading
            *mcd_cmd_ck = *mcd_cmd_ck + 1;
            waitMs(500);
        }

        if (joy & BUTTON_C) {
            *mcd_cmd = 0x1400;
            *mcd_cmd_ck = *mcd_cmd_ck + 1;
            waitMs(500);
        }

        if (joy & BUTTON_START) {
            loop ^= 1;
            waitMs(500);
        }

        if (joy & BUTTON_UP) {

            seek_delay_off ^= 1; //0=delay on (default), 1=delay off

            *mcd_cmd = 0x1600 | (seek_delay_off & 1);
            *mcd_cmd_ck = *mcd_cmd_ck + 1;
            waitMs(500);
        }

        if (joy & BUTTON_DOWN) {
            loop_offset ^= 1;
            waitMs(500);
        }

        // Empty, because all work is done by the interrupt/vblank handlers
        if(frame == 20 && sprite_add)
        {
            VDP_loadTileSet(bg_musica.tileset, 1, CPU);
            VDP_setTileMapEx(BG_B, bg_musica.tilemap,TILE_ATTR_FULL(PAL0, 0,0,0,1), 0,0,0,0, 40,28,CPU);
            PAL_setPalette(PAL0, bg_musica.palette->data, CPU);
            KLog("add sprite");
            k0 = SPR_addSprite(&spr_kim_121, 50, 50, TILE_ATTR(PAL1, FALSE, FALSE, FALSE));
            PAL_setPalette(PAL1, spr_kim_121.palette->data, CPU);
            
            sprite_add= FALSE;
        }

        frame++;
        SPR_update();
        SYS_doVBlankProcess();
    }
}
