#include <genesis.h>

#ifndef _RES_RESOURCES_H_
#define _RES_RESOURCES_H_

extern const SpriteDefinition hero;
extern const TileSet l_tileset;
extern const MapDefinition l_m;
extern const Palette pal_map;

#endif // _RES_RESOURCES_H_
