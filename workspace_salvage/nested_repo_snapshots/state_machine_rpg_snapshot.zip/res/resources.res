SPRITE hero "sprites\hero.png" 4 4 NONE 8

TILESET l_tileset "tiles\state1.png" NONE
MAP l_m "tiles\state1.png" l_tileset NONE
PALETTE pal_map "tiles\state1.png"
